<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-11-17-01-19"/>
  <PLUGIN name="Tone3000MPC" descriptiveName="Tone3000MPC" format="VST" category="Effect" manufacturer="L'Cronx"
          version="1.0" file="%payload-path%/L'Cronx - VST - Tone3000MPC/tone3000mpc.so" uid="54336b4d" isInstrument="0" fileTime="0"
          infoUpdateTime="0" numInputs="2" numOutputs="2" isShell="0"/>
  <preset>Default</preset>
  <state>161.CMlaKA....fQBMDZ....AP0Lq0D....Y....A...............................................................................................................................................................................A..</state>
</pluginstate>
