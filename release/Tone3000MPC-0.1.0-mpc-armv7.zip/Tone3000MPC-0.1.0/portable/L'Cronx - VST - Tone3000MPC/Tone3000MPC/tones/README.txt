Put TONE3000 captures (.nam) and IRs (.wav) here, or download them in the plugin.
