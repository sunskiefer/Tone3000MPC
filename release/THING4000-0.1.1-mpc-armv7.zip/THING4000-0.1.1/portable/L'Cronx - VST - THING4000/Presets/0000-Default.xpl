<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-11-17-12-27"/>
  <PLUGIN name="THING4000" descriptiveName="THING4000" format="VST" category="Effect" manufacturer="L'Cronx"
          version="1.0" file="%payload-path%/L'Cronx - VST - THING4000/thing4000.so" uid="54484e47" isInstrument="0" fileTime="0"
          infoUpdateTime="0" numInputs="2" numOutputs="2" isShell="0"/>
  <preset>Default</preset>
  <state>161.CMlaKA....fQBMDZ....APERNcD...PY....A...............................................................................................................................................................................A..</state>
</pluginstate>
