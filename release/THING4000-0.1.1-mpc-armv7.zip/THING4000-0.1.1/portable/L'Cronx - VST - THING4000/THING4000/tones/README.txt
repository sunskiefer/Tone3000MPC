Put your amp / pedal captures (.nam) and cab IRs (.wav) here. Download them on your PC, then copy them into this folder.
